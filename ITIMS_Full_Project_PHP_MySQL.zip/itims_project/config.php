<?php
declare(strict_types=1);
session_start();
const DB_HOST='127.0.0.1'; const DB_NAME='itims_db'; const DB_USER='root'; const DB_PASS='';
function db(): PDO { static $p=null; if($p instanceof PDO)return $p; $p=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]); return $p; }
function e($v): string { return htmlspecialchars((string)($v??''),ENT_QUOTES,'UTF-8'); }
function require_login(): void { if(empty($_SESSION['user_id'])){header('Location: login.php');exit;} }
function csrf_token(): string { if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function verify_csrf(): void { if(!hash_equals(csrf_token(),(string)($_POST['csrf_token']??''))){http_response_code(403);exit('Invalid security token.');} }
function flash(string $m): void { $_SESSION['flash']=$m; }
